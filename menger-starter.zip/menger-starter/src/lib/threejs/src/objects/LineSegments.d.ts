import { Geometry } from './../core/Geometry';
import { Material } from './../materials/Material';
import { Line } from './Line';
import { BufferGeometry } from '../core/BufferGeometry';

/**
 * @deprecated
 */
export const LineStrip: number;
/**
 * @deprecated
 */
export const LinePieces: number;

export class LineSegments <
	TGeometry extends Geometry | BufferGeometry = Geometry | BufferGeometry,
	TMaterial extends Material | Material[] = Material | Material[]
> extends Line {

	constructor(
		geometry?: TGeometry,
		material?: TMaterial,
		mode?: number
	);

	type: 'LineSegments';
	readonly isLineSegments: true;

}
